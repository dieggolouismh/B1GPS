//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file B1DetectorConstruction.cc
/// \brief Implementation of the B1DetectorConstruction class

#include "B1DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Tubs.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1DetectorConstruction::B1DetectorConstruction()
: G4VUserDetectorConstruction(),
  fScoringVolume(0)
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1DetectorConstruction::~B1DetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* B1DetectorConstruction::Construct()
{  
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();
  
  // Envelope parameters
  //
  G4double env_sizeXY = 20*cm, env_sizeZ = 30*cm;
  G4Material* env_mat = nist->FindOrBuildMaterial("G4_WATER");
   
  // Option to switch on/off checking of volumes overlaps
  //
  G4bool checkOverlaps = true;

  //     
  // World
  //
  G4double world_sizeXY = 1.2*env_sizeXY;
  G4double world_sizeZ  = 1.2*env_sizeZ;
  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
  
  G4Box* solidWorld =    
    new G4Box("World",                       //its name
       0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);     //its size
      
  G4LogicalVolume* logicWorld =                         
    new G4LogicalVolume(solidWorld,          //its solid
                        world_mat,           //its material
                        "World");            //its name
                                   
  G4VPhysicalVolume* physWorld = 
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(),       //at (0,0,0)
                      logicWorld,            //its logical volume
                      "World",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking
                     
  //     
  // Envelope
  //  
  G4Box* solidEnv =    
    new G4Box("Envelope",                    //its name
        0.5*env_sizeXY, 0.5*env_sizeXY, 0.5*env_sizeZ); //its size
      
  G4LogicalVolume* logicEnv =                         
    new G4LogicalVolume(solidEnv,            //its solid
                        env_mat,             //its material
                        "Envelope");         //its name
               
  new G4PVPlacement(0,                       //no rotation
                    G4ThreeVector(),         //at (0,0,0)
                    logicEnv,                //its logical volume
                    "Envelope",              //its name
                    logicWorld,              //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking

  
   //     
  // Cilindros
  //  
 G4Material* mat_int = nist -> FindOrBuildMaterial("G4_POLYSTYRENE");

   G4double innerRadius =17.9*mm;
   G4double outerRadius =19.4*mm;
   G4double hz =10.5*mm; 
   G4double startAngle =0.*deg;
   G4double spanningAngle =360.*deg;

   G4Tubs* solidpozo = new G4Tubs ("pozo", innerRadius, outerRadius, hz, startAngle, spanningAngle);


    G4LogicalVolume* logicalcilindro= new G4LogicalVolume (solidpozo,
							 mat_int,
							 "pozo");

   //Tapas

   G4double innerRadius1 =0.*mm;
   G4double outerRadius1 =19.4*mm;
   G4double hz1 =0.75*mm; 
   G4double startAngle1 =0.*deg;
   G4double spanningAngle1 =360.*deg;
 


 G4Tubs* tapa = new G4Tubs("tapa_inf", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa = new G4LogicalVolume (tapa,
						     mat_int,
						     "tapa_inf");


  //Cilindro 1

   G4RotationMatrix* rotationMatrix = new G4RotationMatrix();
   rotationMatrix -> rotateX(90.*deg);
   G4Tubs* solidpozo1 = new G4Tubs ("pozo1", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro1= new G4LogicalVolume (solidpozo1,
							 mat_int,
							 "pozo1");

   new G4PVPlacement(rotationMatrix,                       //no rotation
                    G4ThreeVector(38.8*mm,0,38.8*mm),                    //at position
                    logicalcilindro1,             //its logical volume
                    "pozo1",                //its name
                    logicEnv,                //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking
   

   // CIlindro 2

   G4Tubs* solidpozo2 = new G4Tubs ("pozo2", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro2= new G4LogicalVolume (solidpozo2,
							 mat_int,
							 "pozo2");

    			new G4PVPlacement(rotationMatrix,
					      G4ThreeVector(0,0,38.8*mm),
					      logicalcilindro2,
					      "pozo",
					      logicEnv,
					      false,
					      0,
					      checkOverlaps);

   // Cilindro 3

   G4Tubs* solidpozo3 = new G4Tubs ("pozo3", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro3= new G4LogicalVolume (solidpozo3,
							 mat_int,
							 "pozo3");

     			new G4PVPlacement(rotationMatrix,
					      G4ThreeVector(-38.8*mm,0,38.8*mm),
					      logicalcilindro3,
					      "pozo3",
					      logicEnv,
					      false,
					      0,
					      checkOverlaps);

   // Cilindro 4

   G4Tubs* solidpozo4 = new G4Tubs ("pozo4", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro4= new G4LogicalVolume (solidpozo4,
							 mat_int,
							 "pozo4");

     				new G4PVPlacement(rotationMatrix,
					      G4ThreeVector(38.8*mm,0,0),
					      logicalcilindro4,
					      "pozo",
					      logicEnv,
					      false,
					      0,
					      checkOverlaps);

   // Cilindro 5

   G4Tubs* solidpozo5 = new G4Tubs ("pozo5", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro5= new G4LogicalVolume (solidpozo5,
							 mat_int,
							 "pozo5");

        			new G4PVPlacement(rotationMatrix,
					      G4ThreeVector(),
					      logicalcilindro5,
					      "pozo5",
					      logicEnv,
					      false,
					      0,
					      checkOverlaps);

   // Cilindro 6

   G4Tubs* solidpozo6 = new G4Tubs ("pozo6", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro6 = new G4LogicalVolume (solidpozo6,
							 mat_int,
							 "pozo6");

	 			 new G4PVPlacement(rotationMatrix,
						G4ThreeVector(-38.8*mm,0,0),
						logicalcilindro6,
						"pozo6",
						logicEnv,
						false,
						0,
						checkOverlaps);
   // Cilindro 7

   G4Tubs* solidpozo7 = new G4Tubs ("pozo7", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro7= new G4LogicalVolume (solidpozo7,
							 mat_int,
							 "pozo7");

	   			new G4PVPlacement(rotationMatrix,
						 G4ThreeVector(38.8*mm,0,-38.8*mm),
						 logicalcilindro7,
						 "pozo7",
						 logicEnv,
						 false,
						 0,
						 checkOverlaps);;

   //Cilindro 8

   G4Tubs* solidpozo8 = new G4Tubs ("pozo8", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro8= new G4LogicalVolume (solidpozo8,
							 mat_int,
							 "pozo8");

	  			new G4PVPlacement(rotationMatrix,
						  G4ThreeVector(0,0,-38.8*mm),
						  logicalcilindro8,
						  "pozo8",
						  logicEnv,
						  false,
						  0,
						  checkOverlaps);

   // Cilindro 9

   G4Tubs* solidpozo9 = new G4Tubs ("pozo9", innerRadius, outerRadius, hz, startAngle, spanningAngle);
   G4LogicalVolume* logicalcilindro9= new G4LogicalVolume (solidpozo9,
							 mat_int,
							 "pozo9");

	   			 new G4PVPlacement(rotationMatrix,
						   G4ThreeVector(-38.8*mm,0,-38.8*mm),
						   logicalcilindro9,
						   "pozo9",
						   logicEnv,
						   false,
						   0,
						   checkOverlaps);
   
  //     
  // Tapas
  //

 //tapa1

 G4Tubs* tapa1 = new G4Tubs("tapa_inf1", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa1 = new G4LogicalVolume (tapa1,
						     mat_int,
						     "tapa_inf1");

 				new G4PVPlacement(rotationMatrix,
						  G4ThreeVector(38.8*mm,-11.25*mm,38.8*mm),
						  logicaltapa1,
						  "tapa_inf1",
						  logicEnv,
						  false,
						  0,
						  checkOverlaps);
 
 //tapa2

 G4Tubs* tapa2 = new G4Tubs("tapa_inf2", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa2 = new G4LogicalVolume (tapa2,
						     mat_int,
						     "tapa_inf2");
 				new G4PVPlacement(rotationMatrix,
						   G4ThreeVector(0,-11.25*mm,38.8*mm),
						   logicaltapa2,
						   "tapa_inf2",
						   logicEnv,
						   false,
						   0,
						   checkOverlaps);
 //tapa3

 G4Tubs* tapa3 = new G4Tubs("tapa_inf3", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa3 = new G4LogicalVolume (tapa3,
						     mat_int,
						     "tapa_inf3");
 				new G4PVPlacement(rotationMatrix,
						   G4ThreeVector(-38.8*mm,-11.25*mm,38.8*mm),
						   logicaltapa3,
						   "tapa_inf3",
						   logicEnv,
						   false,
						   0,
						   checkOverlaps);

 //tapa4

 G4Tubs* tapa4 = new G4Tubs("tapa_inf4", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa4 = new G4LogicalVolume (tapa4,
						     mat_int,
						     "tapa_inf4");
 				new G4PVPlacement(rotationMatrix,
						   G4ThreeVector(38.8*mm,-11.25*mm,0),
						  logicaltapa4,
						  "tapa_inf4",
						  logicEnv,
						  false,
						  0,
						  checkOverlaps);
 //tapa5

 G4Tubs* tapa5 = new G4Tubs("tapa_inf5", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa5 = new G4LogicalVolume (tapa5,
						     mat_int,
						     "tapa_inf5");
  				new G4PVPlacement(rotationMatrix,
						    G4ThreeVector(0,-11.25*mm,0),
						    logicaltapa5,
						    "tapa_inf",
						    logicEnv,
						    false,
						    0,
						    checkOverlaps);
  //tapa6

 G4Tubs* tapa6 = new G4Tubs("tapa_inf6", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa6 = new G4LogicalVolume (tapa6,
						     mat_int,
						     "tapa_inf6");
   				new G4PVPlacement(rotationMatrix,
						     G4ThreeVector(-38.8*mm,-11.25*mm,0),
						     logicaltapa6,
						     "tapa_inf6",
						     logicEnv,
						     false,
						     0,
						     checkOverlaps);
   //tapa7

 G4Tubs* tapa7 = new G4Tubs("tapa_inf7", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa7 = new G4LogicalVolume (tapa7,
						     mat_int,
						     "tapa_inf7");
    				new G4PVPlacement(rotationMatrix,
						      G4ThreeVector(38.8*mm,-11.25*mm,-38.8*mm),
						      logicaltapa7,
						      "tapa_inf7",
						      logicEnv,
						      false,
						      0,
						      checkOverlaps);
    //tapa8

 G4Tubs* tapa8 = new G4Tubs("tapa_inf8", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa8 = new G4LogicalVolume (tapa8,
						     mat_int,
						     "tapa_inf8");

   				new G4PVPlacement(rotationMatrix,
						       G4ThreeVector(0,-11.25*mm,-38.8*mm),
						       logicaltapa8,
						       "tapa_inf8",
						       logicEnv,
						       false,
						       0,
						       checkOverlaps);
     //tapa9

 G4Tubs* tapa9 = new G4Tubs("tapa_inf9", innerRadius1, outerRadius1, hz1, startAngle1, spanningAngle1);
 G4LogicalVolume* logicaltapa9 = new G4LogicalVolume (tapa9,
						     mat_int,
						     "tapa_inf9");
      				new G4PVPlacement(rotationMatrix,
							G4ThreeVector(-38.8*mm,-11.25*mm,-38.8*mm),
							logicaltapa9,
							"tapa_inf9",
							logicEnv,
							false,
							0,
							checkOverlaps);
                
  // Set Shape2 as scoring volume
  //
  
  fScoringVolume = logicaltapa5;

  //
  //always return the physical World
  //
  
  return physWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
